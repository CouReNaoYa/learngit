package com.example.myapplication.ui.listener;

import com.example.myapplication.bean.Movie;
import com.example.myapplication.ui.listener.base.OnGetDataListener;

public interface OnGetMovieDetailListener extends OnGetDataListener<Movie> {
}

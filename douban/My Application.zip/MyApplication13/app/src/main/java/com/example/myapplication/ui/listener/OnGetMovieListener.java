package com.example.myapplication.ui.listener;

import com.example.myapplication.bean.base.MovieResult;
import com.example.myapplication.ui.listener.base.OnGetDataListener;

public interface OnGetMovieListener extends OnGetDataListener<MovieResult> {
}

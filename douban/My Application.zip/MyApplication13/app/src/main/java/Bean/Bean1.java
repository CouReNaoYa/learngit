package Bean;

import java.util.List;

public class Bean1 {


    /**
     * count : 10
     * start : 0
     * total : 31
     * subjects : [{"rating":{"max":10,"average":8.4,"details":{"1":93,"3":5978,"2":508,"5":16134,"4":20542},"stars":"45","min":0},"genres":["剧情","喜剧","战争"],"title":"乔乔的异想世界","casts":[{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1557910186.94.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1557910186.94.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1557910186.94.webp"},"name_en":"Roman Griffin Davis","name":"罗曼·格里芬·戴维斯","alt":"https://movie.douban.com/celebrity/1416281/","id":"1416281"},{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1568812272.92.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1568812272.92.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1568812272.92.webp"},"name_en":"Thomasin McKenzie","name":"托马辛·麦肯齐","alt":"https://movie.douban.com/celebrity/1394824/","id":"1394824"},{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p37050.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p37050.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p37050.webp"},"name_en":"Scarlett Johansson","name":"斯嘉丽·约翰逊","alt":"https://movie.douban.com/celebrity/1054453/","id":"1054453"}],"durations":["108分钟"],"collect_count":218079,"mainland_pubdate":"2020-07-31","has_video":false,"original_title":"Jojo Rabbit","subtype":"movie","directors":[{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589336680.53.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589336680.53.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589336680.53.webp"},"name_en":"Taika Waititi","name":"塔伊加·维迪提","alt":"https://movie.douban.com/celebrity/1076354/","id":"1076354"}],"pubdates":["2019-09-08(多伦多电影节)","2019-11-08(美国)","2020-07-31(中国大陆)"],"year":"2019","images":{"small":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614997041.webp","large":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614997041.webp","medium":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614997041.webp"},"alt":"https://movie.douban.com/subject/30170546/","id":"30170546"},{"rating":{"max":10,"average":5.1,"details":{"1":125,"3":202,"2":240,"5":66,"4":55},"stars":"25","min":0},"genres":["剧情","爱情"],"title":"抵达之谜","casts":[{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1506395043.48.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1506395043.48.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1506395043.48.webp"},"name_en":"Xian Li","name":"李现","alt":"https://movie.douban.com/celebrity/1324619/","id":"1324619"},{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1510552435.61.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1510552435.61.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1510552435.61.webp"},"name_en":"Borui Dong","name":"董博睿","alt":"https://movie.douban.com/celebrity/1364257/","id":"1364257"},{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p38096.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p38096.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p38096.webp"},"name_en":"Xuan Gu","name":"顾璇","alt":"https://movie.douban.com/celebrity/1316959/","id":"1316959"}],"durations":["114分钟"],"collect_count":33607,"mainland_pubdate":"2020-07-31","has_video":false,"original_title":"抵达之谜","subtype":"movie","directors":[{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1536132336.46.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1536132336.46.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1536132336.46.webp"},"name_en":"Wen Song","name":"宋文","alt":"https://movie.douban.com/celebrity/1397719/","id":"1397719"}],"pubdates":["2018-10-05(釜山电影节)","2020-07-31(中国大陆)"],"year":"2018","images":{"small":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614691271.webp","large":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614691271.webp","medium":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614691271.webp"},"alt":"https://movie.douban.com/subject/26871465/","id":"26871465"},{"rating":{"max":10,"average":6.3,"details":{"1":33,"3":621,"2":229,"5":94,"4":307},"stars":"35","min":0},"genres":["动画","奇幻","冒险"],"title":"妙先生","casts":[{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1471147748.38.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1471147748.38.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1471147748.38.webp"},"name_en":"Jing Xu","name":"小连杀","alt":"https://movie.douban.com/celebrity/1345276/","id":"1345276"},{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1521431417.57.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1521431417.57.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1521431417.57.webp"},"name_en":"Ming Song","name":"宝木中阳","alt":"https://movie.douban.com/celebrity/1334350/","id":"1334350"}],"durations":["89分钟"],"collect_count":13362,"mainland_pubdate":"2020-07-31","has_video":false,"original_title":"妙先生","subtype":"movie","directors":[{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1573699266.62.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1573699266.62.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1573699266.62.webp"},"name_en":"Lingxiao Li","name":"李凌霄","alt":"https://movie.douban.com/celebrity/1426357/","id":"1426357"}],"pubdates":["2020-07-31(中国大陆)"],"year":"2020","images":{"small":"http://img9.doubanio.com/view/photo/s_ratio_poster/public/p2614234255.webp","large":"http://img9.doubanio.com/view/photo/s_ratio_poster/public/p2614234255.webp","medium":"http://img9.doubanio.com/view/photo/s_ratio_poster/public/p2614234255.webp"},"alt":"https://movie.douban.com/subject/34888476/","id":"34888476"},{"rating":{"max":10,"average":5.7,"details":{"1":207,"3":2153,"2":1099,"5":160,"4":654},"stars":"30","min":0},"genres":["喜剧","奇幻","冒险"],"title":"多力特的奇幻冒险","casts":[{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p56339.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p56339.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p56339.webp"},"name_en":"Robert Downey Jr.","name":"小罗伯特·唐尼","alt":"https://movie.douban.com/celebrity/1016681/","id":"1016681"},{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1467942867.09.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1467942867.09.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1467942867.09.webp"},"name_en":"Tom Holland","name":"汤姆·赫兰德","alt":"https://movie.douban.com/celebrity/1325351/","id":"1325351"},{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1860.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1860.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1860.webp"},"name_en":"Rami Malek","name":"拉米·马雷克","alt":"https://movie.douban.com/celebrity/1044903/","id":"1044903"}],"durations":["101分钟"],"collect_count":33259,"mainland_pubdate":"2020-07-24","has_video":false,"original_title":"Dolittle","subtype":"movie","directors":[{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p25915.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p25915.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p25915.webp"},"name_en":"Stephen Gaghan","name":"斯蒂芬·加汉","alt":"https://movie.douban.com/celebrity/1045122/","id":"1045122"}],"pubdates":["2020-01-17(美国)","2020-07-24(中国大陆)"],"year":"2020","images":{"small":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614594787.webp","large":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614594787.webp","medium":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614594787.webp"},"alt":"https://movie.douban.com/subject/27000981/","id":"27000981"},{"rating":{"max":10,"average":9.3,"details":{"1":2870,"3":44313,"2":4262,"5":707022,"4":230999},"stars":"50","min":0},"genres":["剧情","科幻","冒险"],"title":"星际穿越","casts":[{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1392653727.04.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1392653727.04.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1392653727.04.webp"},"name_en":"Matthew McConaughey","name":"马修·麦康纳","alt":"https://movie.douban.com/celebrity/1040511/","id":"1040511"},{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p10467.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p10467.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p10467.webp"},"name_en":"Anne Hathaway","name":"安妮·海瑟薇","alt":"https://movie.douban.com/celebrity/1048027/","id":"1048027"},{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p54076.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p54076.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p54076.webp"},"name_en":"Jessica Chastain","name":"杰西卡·查斯坦","alt":"https://movie.douban.com/celebrity/1000225/","id":"1000225"}],"durations":["169分钟"],"collect_count":1770497,"mainland_pubdate":"2014-11-12","has_video":true,"original_title":"Interstellar","subtype":"movie","directors":[{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p673.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p673.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p673.webp"},"name_en":"Christopher Nolan","name":"克里斯托弗·诺兰","alt":"https://movie.douban.com/celebrity/1054524/","id":"1054524"}],"pubdates":["2014-11-07(美国)","2014-11-12(中国大陆)","2020-08-02(中国大陆重映)"],"year":"2014","images":{"small":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614988097.webp","large":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614988097.webp","medium":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614988097.webp"},"alt":"https://movie.douban.com/subject/1889243/","id":"1889243"},{"rating":{"max":10,"average":6.1,"details":{"1":92,"3":2106,"2":629,"5":154,"4":689},"stars":"30","min":0},"genres":["喜剧","动作","动画"],"title":"刺猬索尼克","casts":[{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p276.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p276.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p276.webp"},"name_en":"James Marsden","name":"詹姆斯·麦斯登","alt":"https://movie.douban.com/celebrity/1048023/","id":"1048023"},{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p615.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p615.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p615.webp"},"name_en":"Jim Carrey","name":"金·凯瑞","alt":"https://movie.douban.com/celebrity/1054438/","id":"1054438"},{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589625660.67.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589625660.67.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589625660.67.webp"},"name_en":"Ben Schwartz","name":"本·施瓦茨","alt":"https://movie.douban.com/celebrity/1314604/","id":"1314604"}],"durations":["99分钟"],"collect_count":22617,"mainland_pubdate":"2020-07-31","has_video":false,"original_title":"Sonic the Hedgehog","subtype":"movie","directors":[{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1502164074.72.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1502164074.72.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1502164074.72.webp"},"name_en":"Jeff Fowler","name":"杰夫·福勒","alt":"https://movie.douban.com/celebrity/1024763/","id":"1024763"}],"pubdates":["2020-02-14(美国)","2020-07-31(中国大陆)"],"year":"2020","images":{"small":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614594570.webp","large":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614594570.webp","medium":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614594570.webp"},"alt":"https://movie.douban.com/subject/25905044/","id":"25905044"},{"rating":{"max":10,"average":0,"details":{"1":0,"3":0,"2":0,"5":0,"4":0},"stars":"00","min":0},"genres":["动作"],"title":"十三猎杀","casts":[{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1374035643.97.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1374035643.97.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1374035643.97.webp"},"name_en":"Shangwei Gu","name":"谷尚蔚","alt":"https://movie.douban.com/celebrity/1330813/","id":"1330813"},{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p15963.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p15963.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p15963.webp"},"name_en":"Yan Tang","name":"汤嬿","alt":"https://movie.douban.com/celebrity/1313291/","id":"1313291"},{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1361457954.35.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1361457954.35.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1361457954.35.webp"},"name_en":"Tenma Shibuya","name":"涩谷天马","alt":"https://movie.douban.com/celebrity/1314962/","id":"1314962"}],"durations":["93分钟"],"collect_count":294,"mainland_pubdate":"2020-08-02","has_video":true,"original_title":"十三猎杀","subtype":"movie","directors":[{"avatars":null,"name_en":"","name":"李斌","alt":null,"id":null}],"pubdates":["2020-08-02(中国大陆)"],"year":"2020","images":{"small":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2615288371.webp","large":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2615288371.webp","medium":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2615288371.webp"},"alt":"https://movie.douban.com/subject/27195144/","id":"27195144"},{"rating":{"max":10,"average":5.6,"details":{"1":126,"3":1441,"2":738,"5":68,"4":294},"stars":"30","min":0},"genres":["动作","科幻"],"title":"喋血战士","casts":[{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p53186.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p53186.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p53186.webp"},"name_en":"Vin Diesel","name":"范·迪塞尔","alt":"https://movie.douban.com/celebrity/1041020/","id":"1041020"},{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1566461332.8.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1566461332.8.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1566461332.8.webp"},"name_en":"Eiza González","name":"艾莎·冈萨雷斯","alt":"https://movie.douban.com/celebrity/1233270/","id":"1233270"},{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1430636810.17.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1430636810.17.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1430636810.17.webp"},"name_en":"Sam Heughan","name":"萨姆·修汉","alt":"https://movie.douban.com/celebrity/1182341/","id":"1182341"}],"durations":["109分钟"],"collect_count":21567,"mainland_pubdate":"2020-07-24","has_video":false,"original_title":"Bloodshot","subtype":"movie","directors":[{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1552898494.3.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1552898494.3.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1552898494.3.webp"},"name_en":"Dave Wilson","name":"戴夫·威尔逊","alt":"https://movie.douban.com/celebrity/1412975/","id":"1412975"}],"pubdates":["2020-03-13(美国)","2020-07-24(中国大陆)"],"year":"2020","images":{"small":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614385032.webp","large":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614385032.webp","medium":"http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614385032.webp"},"alt":"https://movie.douban.com/subject/4830483/","id":"4830483"},{"rating":{"max":10,"average":0,"details":{"1":0,"3":0,"2":0,"5":0,"4":0},"stars":"00","min":0},"genres":["爱情","科幻","惊悚"],"title":"致命复活","casts":[{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1582811454.08.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1582811454.08.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1582811454.08.webp"},"name_en":"Wenjun Yan","name":"闫文君","alt":"https://movie.douban.com/celebrity/1432188/","id":"1432188"},{"avatars":null,"name_en":"","name":"徐绍泽","alt":null,"id":null},{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1590992350.44.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1590992350.44.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1590992350.44.webp"},"name_en":"","name":"沈文君","alt":"https://movie.douban.com/celebrity/1438727/","id":"1438727"}],"durations":["90分钟"],"collect_count":173,"mainland_pubdate":"2020-07-31","has_video":false,"original_title":"致命复活","subtype":"movie","directors":[{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1590992333.76.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1590992333.76.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1590992333.76.webp"},"name_en":"","name":"杨乐","alt":"https://movie.douban.com/celebrity/1438726/","id":"1438726"}],"pubdates":["2020-07-31(中国大陆)"],"year":"2020","images":{"small":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2605928267.webp","large":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2605928267.webp","medium":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2605928267.webp"},"alt":"https://movie.douban.com/subject/27148159/","id":"27148159"},{"rating":{"max":10,"average":6.9,"details":{"1":2,"3":38,"2":14,"5":17,"4":29},"stars":"35","min":0},"genres":["剧情"],"title":"白云之下","casts":[{"avatars":{"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1575192240.04.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1575192240.04.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1575192240.04.webp"},"name_en":"Ta Na","name":"塔娜","alt":"https://movie.douban.com/celebrity/1406599/","id":"1406599"},{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1575192389.22.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1575192389.22.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1575192389.22.webp"},"name_en":"Ji Ri Mu Tu","name":"吉日木图","alt":"https://movie.douban.com/celebrity/1423634/","id":"1423634"},{"avatars":{"small":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1553327768.27.webp","large":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1553327768.27.webp","medium":"http://img1.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1553327768.27.webp"},"name_en":"Liya Ai","name":"艾丽娅","alt":"https://movie.douban.com/celebrity/1276893/","id":"1276893"}],"durations":["111分钟"],"collect_count":1701,"mainland_pubdate":"2020-07-31","has_video":false,"original_title":"白云之下","subtype":"movie","directors":[{"avatars":{"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p44531.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p44531.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p44531.webp"},"name_en":"Rui Wang","name":"王瑞","alt":"https://movie.douban.com/celebrity/1318781/","id":"1318781"}],"pubdates":["2019-10-31(东京国际电影节)","2020-07-31(中国大陆)"],"year":"2019","images":{"small":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614904589.webp","large":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614904589.webp","medium":"http://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614904589.webp"},"alt":"https://movie.douban.com/subject/34842217/","id":"34842217"}]
     * title : 正在上映的电影-北京
     */

    private int count;
    private int start;
    private int total;
    private String title;
    public List<SubjectsBean> subjects;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<SubjectsBean> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<SubjectsBean> subjects) {
        this.subjects = subjects;
    }

    public static class SubjectsBean {

        private RatingBean rating;
        private String title;
        private int collect_count;
        private String mainland_pubdate;
        private boolean has_video;
        private String original_title;
        private String subtype;
        private String year;
        private ImagesBean images;
        private String alt;
        private String id;
        private List<String> genres;
        private List<CastsBean> casts;
        private List<String> durations;
        private List<DirectorsBean> directors;
        private List<String> pubdates;

        public RatingBean getRating() {
            return rating;
        }

        public void setRating(RatingBean rating) {
            this.rating = rating;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getCollect_count() {
            return collect_count;
        }

        public void setCollect_count(int collect_count) {
            this.collect_count = collect_count;
        }

        public String getMainland_pubdate() {
            return mainland_pubdate;
        }

        public void setMainland_pubdate(String mainland_pubdate) {
            this.mainland_pubdate = mainland_pubdate;
        }

        public boolean isHas_video() {
            return has_video;
        }

        public void setHas_video(boolean has_video) {
            this.has_video = has_video;
        }

        public String getOriginal_title() {
            return original_title;
        }

        public void setOriginal_title(String original_title) {
            this.original_title = original_title;
        }

        public String getSubtype() {
            return subtype;
        }

        public void setSubtype(String subtype) {
            this.subtype = subtype;
        }

        public String getYear() {
            return year;
        }

        public void setYear(String year) {
            this.year = year;
        }

        public ImagesBean getImages() {
            return images;
        }

        public void setImages(ImagesBean images) {
            this.images = images;
        }

        public String getAlt() {
            return alt;
        }

        public void setAlt(String alt) {
            this.alt = alt;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public List<String> getGenres() {
            return genres;
        }

        public void setGenres(List<String> genres) {
            this.genres = genres;
        }

        public List<CastsBean> getCasts() {
            return casts;
        }

        public void setCasts(List<CastsBean> casts) {
            this.casts = casts;
        }

        public List<String> getDurations() {
            return durations;
        }

        public void setDurations(List<String> durations) {
            this.durations = durations;
        }

        public List<DirectorsBean> getDirectors() {
            return directors;
        }

        public void setDirectors(List<DirectorsBean> directors) {
            this.directors = directors;
        }

        public List<String> getPubdates() {
            return pubdates;
        }

        public void setPubdates(List<String> pubdates) {
            this.pubdates = pubdates;
        }

        public static class RatingBean {
            /**
             * max : 10
             * average : 8.4
             * details : {"1":93,"3":5978,"2":508,"5":16134,"4":20542}
             * stars : 45
             * min : 0
             */

            private int max;
            private double average;
//            private DetailsBean details;
            private String stars;
            private int min;

            public int getMax() {
                return max;
            }

            public void setMax(int max) {
                this.max = max;
            }

            public double getAverage() {
                return average;
            }

            public void setAverage(double average) {
                this.average = average;
            }
//
//            public DetailsBean getDetails() {
//                return details;
//            }
//
//            public void setDetails(DetailsBean details) {
//                this.details = details;
//            }

            public String getStars() {
                return stars;
            }

            public void setStars(String stars) {
                this.stars = stars;
            }

            public int getMin() {
                return min;
            }

            public void setMin(int min) {
                this.min = min;
            }

//            public static class DetailsBean {
//                /**
//                 * 1 : 93.0
//                 * 3 : 5978.0
//                 * 2 : 508.0
//                 * 5 : 16134.0
//                 * 4 : 20542.0
//                 */
//
//                @com.google.gson.annotations.SerializedName("1")
//                private double _$1;
//                @com.google.gson.annotations.SerializedName("3")
//                private double _$3;
//                @com.google.gson.annotations.SerializedName("2")
//                private double _$2;
//                @com.google.gson.annotations.SerializedName("5")
//                private double _$5;
//                @com.google.gson.annotations.SerializedName("4")
//                private double _$4;
//
//                public double get_$1() {
//                    return _$1;
//                }
//
//                public void set_$1(double _$1) {
//                    this._$1 = _$1;
//                }
//
//                public double get_$3() {
//                    return _$3;
//                }
//
//                public void set_$3(double _$3) {
//                    this._$3 = _$3;
//                }
//
//                public double get_$2() {
//                    return _$2;
//                }
//
//                public void set_$2(double _$2) {
//                    this._$2 = _$2;
//                }
//
//                public double get_$5() {
//                    return _$5;
//                }
//
//                public void set_$5(double _$5) {
//                    this._$5 = _$5;
//                }
//
//                public double get_$4() {
//                    return _$4;
//                }
//
//                public void set_$4(double _$4) {
//                    this._$4 = _$4;
//                }
//            }
        }

        public static class ImagesBean {
            /**
             * small : http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614997041.webp
             * large : http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614997041.webp
             * medium : http://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614997041.webp
             */

            private String small;
            private String large;
            private String medium;

            public String getSmall() {
                return small;
            }

            public void setSmall(String small) {
                this.small = small;
            }

            public String getLarge() {
                return large;
            }

            public void setLarge(String large) {
                this.large = large;
            }

            public String getMedium() {
                return medium;
            }

            public void setMedium(String medium) {
                this.medium = medium;
            }
        }

        public static class CastsBean {
            /**
             * avatars : {"small":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1557910186.94.webp","large":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1557910186.94.webp","medium":"http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1557910186.94.webp"}
             * name_en : Roman Griffin Davis
             * name : 罗曼·格里芬·戴维斯
             * alt : https://movie.douban.com/celebrity/1416281/
             * id : 1416281
             */

            private AvatarsBean avatars;
            private String name_en;
            private String name;
            private String alt;
            private String id;

            public AvatarsBean getAvatars() {
                return avatars;
            }

            public void setAvatars(AvatarsBean avatars) {
                this.avatars = avatars;
            }

            public String getName_en() {
                return name_en;
            }

            public void setName_en(String name_en) {
                this.name_en = name_en;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getAlt() {
                return alt;
            }

            public void setAlt(String alt) {
                this.alt = alt;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public static class AvatarsBean {
                /**
                 * small : http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1557910186.94.webp
                 * large : http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1557910186.94.webp
                 * medium : http://img9.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1557910186.94.webp
                 */

                private String small;
                private String large;
                private String medium;

                public String getSmall() {
                    return small;
                }

                public void setSmall(String small) {
                    this.small = small;
                }

                public String getLarge() {
                    return large;
                }

                public void setLarge(String large) {
                    this.large = large;
                }

                public String getMedium() {
                    return medium;
                }

                public void setMedium(String medium) {
                    this.medium = medium;
                }
            }
        }

        public static class DirectorsBean {
            /**
             * avatars : {"small":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589336680.53.webp","large":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589336680.53.webp","medium":"http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589336680.53.webp"}
             * name_en : Taika Waititi
             * name : 塔伊加·维迪提
             * alt : https://movie.douban.com/celebrity/1076354/
             * id : 1076354
             */

            private AvatarsBeanX avatars;
            private String name_en;
            private String name;
            private String alt;
            private String id;

            public AvatarsBeanX getAvatars() {
                return avatars;
            }

            public void setAvatars(AvatarsBeanX avatars) {
                this.avatars = avatars;
            }

            public String getName_en() {
                return name_en;
            }

            public void setName_en(String name_en) {
                this.name_en = name_en;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getAlt() {
                return alt;
            }

            public void setAlt(String alt) {
                this.alt = alt;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public static class AvatarsBeanX {
                /**
                 * small : http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589336680.53.webp
                 * large : http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589336680.53.webp
                 * medium : http://img3.doubanio.com/view/celebrity/s_ratio_celebrity/public/p1589336680.53.webp
                 */

                private String small;
                private String large;
                private String medium;

                public String getSmall() {
                    return small;
                }

                public void setSmall(String small) {
                    this.small = small;
                }

                public String getLarge() {
                    return large;
                }

                public void setLarge(String large) {
                    this.large = large;
                }

                public String getMedium() {
                    return medium;
                }

                public void setMedium(String medium) {
                    this.medium = medium;
                }
            }
        }
    }
}
